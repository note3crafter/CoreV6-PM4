<h1>CoreV6 ALPHA<img src="https://github.com/note3crafter/Core-V5/blob/main/resources/icon.png" height="64" width="64" align="left"></img></h1>
<br />
Für Pocketmine API 4.0

Du willst helfen? Hier mein Discord! [![Discord](https://img.shields.io/discord/427472879072968714.svg?style=flat-square&label=discord&colorB=7289da)](https://discord.gg/Pebq8Wu) <br>
# Download und Wichtig 

- [Hier downloaden](https://poggit.pmmp.io/ci/note3crafter/Core-V6/Core-V6)!
  Das Core Plugin wurde speziell für CityBuild Server entwickelt!
# Neues!
-v.6.0.3 ALPHA 
Neue Blöcke Hinzugefügt! Sind setzbar aber nicht korrekt abbaubar und plazierbar (treppen & falltür)
# Fehler & Bugs
Aktuell ist sie Instabiel! Sie befindet sich in der Alpha Phase!
# Mindestanforderungen 
- 2 Kern CPU (Bestenfalls hohe Singlecore Performance)
- 1GB Ram 
- 1GB Festplatte -

# Für die Zukunft Geplant :
- ScoreBoard Feature überarbeiten
- Weitere Commands wie : /top, /milk, /nofire
- Neuschreiben des Booster Commands
- Neuschreiben des Ban Systems
- API für das Economy System
- Internes World Edit System
- Language System (Sprachen System) - Da es sehr Arbeitsintensiv ist, kann dies noch dauern!
  -> Mit Auswahl eigener Sprachen und Erweiterung auf weiterer Sprachen!
- Amboss & Enchantment Table - Geplant aber vermutlich eher nicht
- Chest Shop System

# Features
- [Alle Commands](https://github.com/note3crafter/Core-V5/blob/main/resources/commands.md)
- Multi Language Support!
- [Vanilla Redstone](https://github.com/tedo0627/RedstoneCircuit_PMMP-Plugin) (by [tedo0627](https://github.com/tedo0627))
- Sämtliche Items der 1.16 sind drinne!
- [AntiXray](https://github.com/HimmelKreis4865/AntiXray) & [HeadSystem](https://github.com/HimmelKreis4865/BetterSkulls) (by HimmelKreis4865)
- [MCPEtoDiscord](https://github.com/JaxkDev/MCPEToDiscord) (by [JaxkDev](https://github.com/JaxkDev))
- VoteSystem   
- ClanSystem
- HeiratsSystem
- FreundeSystem
- Perks, Booster und vieles Weiteres
- Intregriertes ScoreBoard (Kann derzeit nicht Selbst Bearbeitet werden)  
- Funktionierender [Braustand](https://github.com/CortexPE/TeaSpoon), [Jukebox](https://github.com/JaxkDev/JukeBox-pmmp), [Beacon](https://github.com/jasonwynn10/PM-Beacons) & [Kessel](https://github.com/CortexPE/TeaSpoon)
- NetheriteRüstung, Barren, Schrott sowie Werkzeuge
- Viele Weitere Kleinigkeiten
- Gruppensystem (Inkompatible zu PurePerms!!!)
- Farbiges Schreiben mit &
- Economy System (Kompatible mit EconomyAPI) (Money.yml kann weitergenutzt werden)
- World Managment System

# Hilfe & Support
Ich werde die Core solange wie Möglich Aktuell halten und Updaten sofern es meine Zeit zulässt...
Beachtet die Configs etc und stellt dort eure sachen ein... 
Und an unseren Forker! Gebt das Plugin nicht als Euers aus! Ich habe eine menge arbeit reingsteckt über Jahre!

# Großes Dankeschön geht an :

- [tim03we](https://github.com/tim03we) (Ban & MSG System)
- xxflow (Heiratsystem & Payall)
- Aneoxic (Für das Grundgerüst und den Einstig)
- [FleekRush](https://github.com/FleekRush) (Für das Boostersystem)
- [JaxkDev](https://github.com/JaxkDev) (Für die MCPE to Discord Codes die ich verwende & JukeBox-pmmp)
- [Crasher508](https://github.com/Crasher508) aka KommandToasti (Fürs repaieren mancher dinge! und er ist der Beste!)
- [CortexPE](https://github.com/CortexPE) (Für ein Teil das ich von Teaspoon mit Intregiert habe) 
- [HimmelKreis4865](https://github.com/HimmelKreis4865) (Für AntiXray & BetterSkulls)
- [MDevPmmP](https://github.com/MarlonDevPMMP) (Für das GroupSystem, EconomySystem)
- [TheBalkanDev](https://github.com/TheBalkanDev) (Für das Invsee/Enderinvsee)  
- [TuranicTeam](https://github.com/TuranicTeam) (Für Sämtliche Items/Blöcke etc)
- [Muqsit](https://github.com/Muqsit) (Für das InvMenü)
- [jojoe77777](https://github.com/jojoe77777) (Für FormAPI)
- [jasonwynn10](https://github.com/jasonwynn10) (Beacons)
- [LookitsAku](https://github.com/Akuroma) & und vielen vielen weiteren Helfern!

2017-2021 ©NoteLand & TheNote/Rudolf2000 







