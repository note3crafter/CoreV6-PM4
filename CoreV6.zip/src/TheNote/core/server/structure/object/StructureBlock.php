<?php

//   ╔═════╗╔═╗ ╔═╗╔═════╗╔═╗    ╔═╗╔═════╗╔═════╗╔═════╗
//   ╚═╗ ╔═╝║ ║ ║ ║║ ╔═══╝║ ╚═╗  ║ ║║ ╔═╗ ║╚═╗ ╔═╝║ ╔═══╝
//     ║ ║  ║ ╚═╝ ║║ ╚══╗ ║   ╚══╣ ║║ ║ ║ ║  ║ ║  ║ ╚══╗
//     ║ ║  ║ ╔═╗ ║║ ╔══╝ ║ ╠══╗   ║║ ║ ║ ║  ║ ║  ║ ╔══╝
//     ║ ║  ║ ║ ║ ║║ ╚═══╗║ ║  ╚═╗ ║║ ╚═╝ ║  ║ ║  ║ ╚═══╗
//     ╚═╝  ╚═╝ ╚═╝╚═════╝╚═╝    ╚═╝╚═════╝  ╚═╝  ╚═════╝
//   Copyright by TheNote! Not for Resale! Not for others
//

namespace TheNote\core\server\structure\object;

use TheNote\core\server\utils\SimpleBlockData;
use pocketmine\utils\Random;

class StructureBlock {

    public $blocks = [];
    public function addBlock(SimpleBlockData $block) {
        $this->blocks[] = $block;
    }

    public function getBlock(Random $random): ?SimpleBlockData {
        if(count($this->blocks) === 0) {
            return null;
        }
        return $this->blocks[$random->nextBoundedInt(count($this->blocks))];
    }

    public function toArray(Random $random) {
        $targetBlock = $this->getBlock($random);

        return [$targetBlock->getId(), $targetBlock->getMeta()];
    }
}